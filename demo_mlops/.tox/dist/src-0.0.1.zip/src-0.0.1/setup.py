from setuptools import setup, find_packages, version

setup(
    name = "src",
    version = "0.0.1",
    description = "This is winequality package", 
    author = "akshay",
    packages = find_packages(),
    license = "MIT"
)